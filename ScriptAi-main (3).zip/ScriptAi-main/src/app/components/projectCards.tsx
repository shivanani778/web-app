import React from 'react'

const projectCards = () => {
	return (
		<div className='w-full flex items-center justify-center'>

			<div className='w-2/12'>
				up
			</div>

			<div className='w-10/12 '>



			</div>


		</div>
	)
}

export default projectCards
